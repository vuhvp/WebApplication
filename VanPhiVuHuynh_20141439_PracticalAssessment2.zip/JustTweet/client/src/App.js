import "./App.css";
import MainApp from "./components/app/app";

function App() {
  return <MainApp />;
}

export default App;
