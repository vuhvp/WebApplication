import React, { Component } from "react";
import { Image } from "react-bootstrap";

class ProfileCover extends Component {
  styles = {
    backgroundImage: "url(https://picsum.photos/2000/400)",
    backgroundPosition: "center",
    backgroundSize: "cover",
    backgroundRepeat: "no-repeat",
    height: "400px",
  };

  render() {
    return (
      <div>
        <div className="profile-cover position-relative" style={this.styles}>
          <Image className="img-fluid position-absolute rounded-circle avatar" src="https://picsum.photos/200?random=10" />
        </div>
      </div>
    );
  }
}

export default ProfileCover;
