import React, { Component } from "react";
import { Container, Row, Col, Image, Button } from "react-bootstrap";

class RightPanel extends Component {
  render() {
    return (
      <Container fluid className="py-3">
        <h3>Who to follow</h3>
        <a href="https://getbootstrap.com/docs/5.2/utilities/text/#text-decoration" className="text-decoration-none">
          Refresh
        </a>{" "}
        <a href="https://getbootstrap.com/docs/5.2/utilities/text/#text-decoration" className="text-decoration-none">
          View all
        </a>
        <div className="mb-4"></div>
        <Row className="align-items-md-center py-2">
          <Col md={3}>
            <Image className="img-fluid rounded-circle" src="https://picsum.photos/100?random=7" />
          </Col>
          <Col>
            <div>
              <strong>Adam</strong> @adam123
            </div>
            <Button variant="outline-primary" size="sm" className="w-50">
              Follow
            </Button>
          </Col>
        </Row>
        <Row className="align-items-md-center py-2">
          <Col md={3}>
            <Image className="img-fluid rounded-circle" src="https://picsum.photos/100?random=8" />
          </Col>
          <Col>
            <div>
              <strong>Joby</strong> @jjoby
            </div>
            <Button variant="outline-primary" size="sm" className="w-50">
              Follow
            </Button>
          </Col>
        </Row>
        <Row className="align-items-md-center py-2">
          <Col md={3}>
            <Image className="img-fluid rounded-circle" src="https://picsum.photos/100?random=9" />
          </Col>
          <Col>
            <div>
              <strong>Deepika</strong> @pikad
            </div>
            <Button variant="outline-primary" size="sm" className="w-50">
              Follow
            </Button>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default RightPanel;
