import React, { Component } from "react";
import { Navbar, Nav, Container, Form, FormControl, Button } from "react-bootstrap";

class NavbarComponent extends Component {
  render() {
    return (
      <Navbar bg="white" expand="lg">
        <Container fluid>
          <Navbar.Toggle aria-controls="navbarScroll" />
          <Navbar.Collapse id="navbarScroll">
            <Nav className="me-auto my-2 my-lg-0" style={{ maxHeight: "100px" }} navbarScroll>
              <Nav.Link href="#home">Home</Nav.Link>
              <Nav.Link href="#moments">Moments</Nav.Link>
              <Nav.Link href="#notifications">Notifications</Nav.Link>
              <Nav.Link href="#messages">Messages</Nav.Link>
            </Nav>
            <Form className="d-flex">
              <FormControl type="search" placeholder="Search Twitter" className="me-2" aria-label="Search" />
              <Button variant="primary">Tweet</Button>
            </Form>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    );
  }
}

export default NavbarComponent;
