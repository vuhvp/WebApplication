import React, { Component } from "react";
import { Container, Row, Col } from "react-bootstrap";

class ProfileStats extends Component {
  render() {
    return (
      <Container id="profile-stat-container" fluid className="border py-2">
        <Row md="auto" className="justify-content-md-center text-center">
          <Col className="active">
            <div>Tweets</div>
            <div>{this.props.tweetCount}</div>
          </Col>
          <Col>
            <div>Followings</div>
            <div>0</div>
          </Col>
          <Col>
            <div>Followers</div>
            <div>0</div>
          </Col>
          <Col>
            <div>Likes</div>
            <div>0</div>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default ProfileStats;
