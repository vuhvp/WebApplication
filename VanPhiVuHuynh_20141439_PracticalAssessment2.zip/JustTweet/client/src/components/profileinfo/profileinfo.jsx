import React, { Component } from "react";
import { Button, Container, Row, Col, Image } from "react-bootstrap";

class ProfileInfo extends Component {
  render() {
    return (
      <Container fluid className="py-3">
        <div>
          <h4>{this.props.profile.fullName}</h4>
          <p>@{this.props.profile.userName}</p>
          <p>
            <a href="https://twitter.com/?lang=en" className="text-decoration-none">
              twitter.com/{this.props.profile.userName}
            </a>
          </p>
          <p>
            <a href="https://www.google.com/maps" className="text-decoration-none">
              {this.props.profile.location}
            </a>
          </p>
          <p>{new Date(this.props.profile.joinedDate).toLocaleDateString()}</p>
          <Button variant="primary" className="w-100">
            Tweet to {this.props.profile.fullName}
          </Button>
        </div>
        <div className="mt-5">
          <a href="https://picsum.photos/" className="text-decoration-none">
            1,142 Photos and videos
          </a>
          <Row md={3}>
            <Col className="my-1">
              <Image className="img-fluid" src="https://picsum.photos/200?random=1" />
            </Col>
            <Col className="my-1">
              <Image className="img-fluid" src="https://picsum.photos/200?random=2" />
            </Col>
            <Col className="my-1">
              <Image className="img-fluid" src="https://picsum.photos/200?random=3" />
            </Col>
            <Col className="my-1">
              <Image className="img-fluid" src="https://picsum.photos/200?random=4" />
            </Col>
            <Col className="my-1">
              <Image className="img-fluid" src="https://picsum.photos/200?random=5" />
            </Col>
            <Col className="my-1">
              <Image className="img-fluid" src="https://picsum.photos/200?random=6" />
            </Col>
          </Row>
        </div>
      </Container>
    );
  }
}

export default ProfileInfo;
