import React, { Component } from "react";
import axios from "axios";
import { Button, Container, Row, Col, Image, Form } from "react-bootstrap";

class NewTweet extends Component {
  constructor(props) {
    super(props);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  async handleSubmit(e) {
    e.preventDefault();
    const data = {
      fullName: this.props.profile.fullName,
      userName: this.props.profile.userName,
      tweetDesc: e.target.tweetDesc.value,
    };
    const result = await axios.post("http://localhost:3100/tweets", data);
    if (result.statusText === "OK") {
      this.props.refreshTweet();
      e.target.tweetDesc.value = "";
    }
  }

  render() {
    return (
      <Container fluid className="border-bottom py-3">
        <Row>
          <Col md={2}>
            <Image className="img-fluid rounded-circle" src="https://picsum.photos/200?random=10" />
          </Col>
          <Col>
            <Form onSubmit={this.handleSubmit}>
              <Form.Control as="textarea" name="tweetDesc" placeholder="What's happening?" style={{ height: "100px" }} />
              <Button className="mt-3" variant="primary" type="submit">
                Tweet
              </Button>
            </Form>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default NewTweet;
