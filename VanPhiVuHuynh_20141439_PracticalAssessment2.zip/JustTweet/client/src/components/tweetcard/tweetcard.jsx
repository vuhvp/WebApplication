import React, { Component } from "react";
import axios from "axios";
import { Container, Row, Col, Image, Button } from "react-bootstrap";

class TweetCard extends Component {
  async deleteTweet(id) {
    const url = "http://localhost:3100/tweets/" + id;
    const result = await axios.delete(url);
    if (result.statusText === "OK") {
      this.props.refreshTweet();
    }
  }

  render() {
    return (
      <Container fluid className="border-bottom py-3">
        <Row>
          <Col md={{ offset: 2 }}>
            {/* https://stackoverflow.com/a/50607453 */}
            <strong>{this.props.fullName}</strong> @{this.props.userName} - {new Date(this.props.date).toLocaleDateString()}
          </Col>
        </Row>
        <Row>
          <Col md={2}>
            <Image className="img-fluid rounded-circle" src="https://picsum.photos/200?random=10" />
          </Col>
          <Col className="d-flex flex-column justify-content-between">
            <div className="content">{this.props.tweetDesc}</div>
            <Row md="auto" className="mt-3">
              <Col>0</Col>
              <Col>0</Col>
              <Col>0</Col>
            </Row>
          </Col>
          <Col md="auto">
            <Button onClick={() => this.deleteTweet(this.props.id)} className="float-right">
              x
            </Button>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default TweetCard;
