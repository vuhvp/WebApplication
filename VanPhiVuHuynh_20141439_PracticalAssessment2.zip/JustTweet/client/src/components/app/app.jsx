import React, { Component } from "react";
import axios from "axios";
import { Container, Row, Col } from "react-bootstrap";
import NavbarComponent from "../navbar/navbar";
import ProfileCover from "../profilecover/profilecover";
import ProfileStats from "../profilestats/profilestats";
import ProfileInfo from "../profileinfo/profileinfo";
import NewTweet from "../newtweet/newtweet";
import TweetCard from "../tweetcard/tweetcard";
import RightPanel from "../rightpanel/rightpanel";

class MainApp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      profile: null,
      tweetCount: 0,
      tweets: [],
    };

    this.getTweets = this.getTweets.bind(this);
  }

  async componentDidMount() {
    await this.getProfileData();
    await this.getTweets();
  }

  async getProfileData() {
    const data = await axios.get("http://localhost:3100/profile");
    this.setState({ profile: data.data.profile });
  }

  async getTweets() {
    const data = await axios.get("http://localhost:3100/tweets");
    this.setState({ tweets: data.data.tweets, tweetCount: data.data.tweets.length });
  }

  render() {
    return (
      <div>
        <NavbarComponent />
        <ProfileCover />
        <ProfileStats tweetCount={this.state.tweetCount} />
        <div id="justTweet-body">
          <Container fluid>
            <Row>
              {/* https://stackoverflow.com/a/51534051 */}
              <Col>{this.state.profile && <ProfileInfo profile={this.state.profile} />}</Col>
              <Col md={6} className="bg-white">
                {this.state.profile && <NewTweet profile={this.state.profile} refreshTweet={this.getTweets} />}
                {this.state.tweets.map((tweet) => (
                  <TweetCard
                    key={tweet._id}
                    id={tweet._id}
                    fullName={tweet.fullName}
                    userName={tweet.userName}
                    date={tweet.date}
                    tweetDesc={tweet.tweetDesc}
                    refreshTweet={this.getTweets}
                  />
                ))}
              </Col>
              <Col>
                <RightPanel />
              </Col>
            </Row>
          </Container>
        </div>
      </div>
    );
  }
}

export default MainApp;
