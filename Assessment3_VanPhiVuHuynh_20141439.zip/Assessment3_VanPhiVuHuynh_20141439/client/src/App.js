import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import MainPage from "./pages/MainPage";

function App() {
  return <MainPage />;
}

export default App;
