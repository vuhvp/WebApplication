import React, { Component } from "react";
import { format } from "date-fns";
import cityTimezones from "city-timezones";
import axios from "axios";
import { Container, Row, Col, Image, Button } from "react-bootstrap";

class FlightCard extends Component {
  getArrivalTime(data) {
    let result;

    // Obtained from kevinroberts, https://github.com/kevinroberts/city-timezones
    // Purpose: To get timezone of arrival
    const timezones = cityTimezones.lookupViaCity(data.arrival);
    timezones.forEach((tz) => {
      // If condition here in case 2 countries have same city name
      // eg: Melbourne in Victoria, Australia and Melbourne in Florida, USA
      if (tz.country === data.arrivalCountry) {
        const arrivalTz = tz.timezone;

        // Obtained from Nosredna, https://stackoverflow.com/a/1133814
        // Purpose: To convert string to number
        const time = data.travelTime.split(":");
        const hour = Number(time[0]);
        const minute = Number(time[1]);

        // Calculate arrival time by adding travel time to departure time
        const arrivalTime = new Date(data.departureTime);
        arrivalTime.setHours(arrivalTime.getHours() + hour);
        arrivalTime.setMinutes(arrivalTime.getMinutes() + minute);

        // Obtained from Nosredna, https://stackoverflow.com/a/49648065
        // Purpose: To get date and time of arrival
        const options = {
          year: "numeric",
          month: "numeric",
          day: "numeric",
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZone: arrivalTz,
        };
        const formatter = new Intl.DateTimeFormat("sv-SE", options);
        result = formatter.format(new Date(arrivalTime));
      }
    });
    return result;
  }

  formatTravelTime(travelTime) {
    const time = travelTime.split(":");
    const hour = time[0];
    const minute = time[1];

    let result = hour + " hr ";
    if (Number(minute) > 0) {
      result += minute + " min";
    }
    return result;
  }

  async onEdit(id) {
    const url = "http://localhost:3100/flights/" + id;
    const result = await axios.put(url, {});
    if (result.statusText === "OK") {
      this.props.updateData(result.data);
    }
  }

  async onDelete(id) {
    const url = "http://localhost:3100/flights/" + id;
    const result = await axios.delete(url);
    if (result.statusText === "OK") {
      this.props.updateData(result.data);
    }
  }

  render() {
    const arrivalTime = this.getArrivalTime(this.props.data);
    return (
      <Container fluid>
        <Row>
          <Col md={{ offset: 2 }}>Departure</Col>
          <Col md={{ offset: 2 }}>Arrival</Col>
        </Row>
        <Row>
          <Col md="2" className="d-flex flex-column align-items-center justify-content-center">
            <span className="text-center">{this.props.data.airplane}</span>
          </Col>
          <Col className="d-flex flex-column justify-content-center">
            <h2>{this.props.data.departure}</h2>
            {/* Obtained from siva surya, https://stackoverflow.com/a/63296319 */}
            {/* Purpose: to format date time */}
            <h5>{format(new Date(this.props.data.departureTime), "hh:mm a")}</h5>
            <span>{new Date(this.props.data.departureTime).toDateString()}</span>
          </Col>
          <Col md="auto" className="d-flex flex-column align-items-center justify-content-center">
            <Image className="flight-icon" fluid src="https://cdn.iconscout.com/icon/free/png-256/plane-167-474991.png" />
            <h6>{this.formatTravelTime(this.props.data.travelTime)}</h6>
          </Col>
          <Col className="d-flex flex-column justify-content-center text-end">
            <h2>{this.props.data.arrival}</h2>
            <h5>{format(new Date(arrivalTime), "hh:mm a")}</h5>
            <span>{new Date(arrivalTime).toDateString()}</span>
          </Col>
          <Col md="3" className="d-flex flex-column justify-content-center">
            <p className="mb-2">
              Flight: <strong>{this.props.data.flightCode}</strong>
            </p>
            <p className="mb-2">
              Gate: <strong>{this.props.data.gate}</strong>
            </p>
            <p className="mb-2">
              Aircraft: <strong>{this.props.data.aircraft}</strong>
            </p>
            <p className="mb-2">
              Status: <strong>{this.props.data.status}</strong>
            </p>
          </Col>
        </Row>
        <Row>
          <Col md={{ offset: 9 }}>
            <Button variant="secondary" size="sm" className="me-3" onClick={() => this.onEdit(this.props.data.id)}>
              Edit
            </Button>
            <Button variant="danger" size="sm" onClick={() => this.onDelete(this.props.data.id)}>
              Delete
            </Button>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default FlightCard;
