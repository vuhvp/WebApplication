import React, { Component } from "react";
import axios from "axios";
import { Form, Button } from "react-bootstrap";

class AddFlight extends Component {
  constructor(props) {
    super(props);
    this.onSubmit = this.onSubmit.bind(this);
  }

  async onSubmit(e) {
    e.preventDefault();
    const data = {
      flightCode: e.target.flightCode.value,
      departure: e.target.departure.value,
      departureCountry: e.target.departureCountry.value,
      arrival: e.target.arrival.value,
      arrivalCountry: e.target.arrivalCountry.value,
      departureTime: e.target.departureTime.value,
      travelTime: e.target.travelTime.value,
      gate: e.target.gate.value,
      airplane: e.target.airplane.value,
      aircraft: e.target.aircraft.value,
    };
    const result = await axios.post("http://localhost:3100/flights", data);
    if (result.statusText === "OK") {
      this.props.updateData(result.data);
    }
  }

  render() {
    return (
      <Form onSubmit={this.onSubmit}>
        <Form.Group className="mb-3">
          <Form.Label>Flight Code</Form.Label>
          <Form.Control type="text" name="flightCode" required />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Departure</Form.Label>
          <Form.Control type="text" name="departure" required />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Departure Country</Form.Label>
          <Form.Control type="text" name="departureCountry" required />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Arrival</Form.Label>
          <Form.Control type="text" name="arrival" required />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Arrival Country</Form.Label>
          <Form.Control type="text" name="arrivalCountry" required />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Departure Time</Form.Label>
          <Form.Control type="text" placeholder="20 June 2022 23:00" name="departureTime" required />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Travel Time</Form.Label>
          <Form.Control type="text" placeholder="5:00" name="travelTime" required />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Gate</Form.Label>
          <Form.Control type="text" name="gate" required />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Airplane</Form.Label>
          <Form.Control type="text" name="airplane" required />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Aircraft</Form.Label>
          <Form.Control type="text" name="aircraft" required />
        </Form.Group>
        <Button variant="primary" type="submit" className="me-3">
          Submit
        </Button>
        <Button variant="secondary" type="reset">
          Reset
        </Button>
      </Form>
    );
  }
}

export default AddFlight;
