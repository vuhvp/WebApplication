import React, { Component } from "react";
import axios from "axios";
import { ListGroup, Container, Row, Col } from "react-bootstrap";
import FlightCard from "../components/FlightCard";
import AddFlight from "../components/AddFlight";

class MainPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      flights: [],
    };
    this.onUpdateData = this.onUpdateData.bind(this);
  }

  async componentDidMount() {
    await this.getData();
  }

  async getData() {
    const result = await axios.get("http://localhost:3100/flights");
    if (result.status === 200) {
      this.setState({
        flights: result.data,
      });
    }
  }

  onUpdateData(data) {
    this.setState({
      flights: data,
    });
  }

  render() {
    return (
      <Container className="mb-5">
        <h1 className="text-center mb-5">Perth Airport</h1>
        <Row>
          <Col md="8">
            <ListGroup className="mt-3">
              {this.state.flights.map((f) => {
                return (
                  <ListGroup.Item key={f.id}>
                    <FlightCard data={f} updateData={this.onUpdateData} />
                  </ListGroup.Item>
                );
              })}
            </ListGroup>
          </Col>
          <Col>
            <h3>Add New Flight</h3>
            <AddFlight updateData={this.onUpdateData} />
          </Col>
        </Row>
      </Container>
    );
  }
}

export default MainPage;
